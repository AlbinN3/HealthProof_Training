Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_header("Accept-Language", 
		"en-GB,en;q=0.9");

	web_url("petstore.octoperf.com", 
		"URL=https://petstore.octoperf.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("NID=526=FWbyTlna706aVGqMgn4dMMUu3NkM89v1MDGoVXAxapr_eNQBZnzFrlpOnANq-O-zIURJl8xPc3Bc-xFuZgYv6-islOJwr-RkKiQDcxCKwzVh2-GSGOHrdYvuKjAB4BlnCQVyJXOfSJyICUrKtZMBnoofvVLYVAI7gqlOMA2Ij9ag51yTSx7CJ4WXPojZRX6LGMNla3dGlj-iNpPc; DOMAIN=accounts.google.com");

	web_add_auto_header("Accept-Language", 
		"en-GB,en-US;q=0.9,en;q=0.8");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	web_revert_auto_header("Accept-Language");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=113", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://dns.google/dns-query?dns=AAABAAABAAAAAAABA3d3dwdnc3RhdGljA2NvbQAAAQABAAApEAAAAAAAAFQADABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "Referer=", ENDITEM, 
		LAST);

	web_add_header("Accept-Language", 
		"en-GB,en-US;q=0.9,en;q=0.8");

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=13:3CjdUKOBYsjKOzwl9Mo9acZGXITqMvPvH6uMz3MfPno&cup2hreq=39023b9866fe4222f158adf8fb8e149692f6d48d8eb005925a3de0f07fb4edc0", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chromecrx\",\"acceptformat\":\"crx3\",\"app\":[{\"appid\":\"ghbmnnjooekpmoecnnnilnnbdlolhkhi\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":6906,\"installedby\":\"external\",\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"2.1.98.1\"}]},\"ping\":{\"ping_freshness\":\"{06910f1e-89ee-404d-8d8d-8b77557cf160}\",\"rd\":6913},\"updatecheck\":{},\"version\":\"1.98.1\"},{\"appid\":\"mbopgmdnpcbohhpnfglgohlbhfongabi\",\"cohort\":\"1::\",\""
		"enabled\":true,\"installdate\":6906,\"installedby\":\"internal\",\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"2.6.6.8\"}]},\"ping\":{\"ping_freshness\":\"{1bc1e575-d2c3-4a83-bdc0-89b0e5947e0d}\",\"rd\":6913},\"updatecheck\":{},\"version\":\"6.6.8\"},{\"appid\":\"nmmhkkegccagdldgiimedpiccmgmieda\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":6906,\"installedby\":\"other\",\"lang\":\"en-GB\",\"packages\":{\"package\":[{\"fp\":\"2.1.0.0.6\"}]},\"ping\":{\"ping_freshness\":\""
		"{de632c16-181c-43b3-939d-dc8f96440e3a}\",\"rd\":6913},\"updatecheck\":{},\"version\":\"1.0.0.6\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":16,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.19045.6332\"},\"prodversion\":\"113.0.5672.93\",\"protocol\":\"3.1\",\"requestid\":\""
		"{0c012f4d-76d5-40a2-a905-6f498da235b7}\",\"sessionid\":\"{35e44968-8dae-46c2-b017-e854e5493111}\",\"updaterversion\":\"113.0.5672.93\"}}", 
		EXTRARES, 
		"Url=https://dns.google/dns-query?dns=AAABAAABAAAAAAABA3d3dwdnc3RhdGljA2NvbQAAAQABAAApEAAAAAAAAFQADABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "Referer=", ENDITEM, 
		LAST);

	web_add_header("Accept-Language", 
		"en-GB,en;q=0.9");

	web_url("Catalog.action", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://dns.google/dns-query?dns=AAABAAABAAAAAAABCHBldHN0b3JlCG9jdG9wZXJmA2NvbQAAAQABAAApEAAAAAAAAE4ADABKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "Referer=", ENDITEM, 
		"Url=https://dns.google/dns-query?dns=AAABAAABAAAAAAABEGNvbnRlbnQtYXV0b2ZpbGwKZ29vZ2xlYXBpcwNjb20AAAEAAQAAKRAAAAAAAABEAAwAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "Referer=", ENDITEM, 
		"Url=https://dns.google/dns-query?dns=AAABAAABAAAAAAABEGNvbnRlbnQtYXV0b2ZpbGwKZ29vZ2xlYXBpcwNjb20AAEEAAQAAKRAAAAAAAABEAAwAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "Referer=", ENDITEM, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChRDaHJvbWUvMTEzLjAuNTY3Mi45MxIQCd-HvMqPGywPEgUNAo_7aA==?alt=proto", "Referer=", ENDITEM, 
		LAST);

	return 0;
}