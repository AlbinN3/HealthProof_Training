Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.9");

	web_url("demowebshop.tricentis.com", 
		"URL=https://demowebshop.tricentis.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("__utma=78382081.1582594478.1764995607.1764995607.1764995607.1; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmc=78382081; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmz=78382081.1764995607.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmt=1; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmb=78382081.1.10.1764995607; DOMAIN=demowebshop.tricentis.com");

	web_url("Log in", 
		"URL=https://demowebshop.tricentis.com/login", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}